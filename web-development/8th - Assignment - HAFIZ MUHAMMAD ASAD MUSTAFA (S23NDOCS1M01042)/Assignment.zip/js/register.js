// JS for register page
